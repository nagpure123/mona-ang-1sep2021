import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngswitch',
  templateUrl: './ngswitch.component.html',
  styleUrls: ['./ngswitch.component.css']
})
export class NgswitchComponent implements OnInit {
  opt1:boolean =true


  change(gender:boolean):void{

    this.opt1=gender
  }
  constructor() { }


  ngOnInit(): void {
  }

}


  



   
