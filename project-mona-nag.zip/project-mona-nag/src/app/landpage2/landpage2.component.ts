import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landpage2',
  templateUrl: './landpage2.component.html',
  styleUrls: ['./landpage2.component.css']
})
export class Landpage2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
