import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Landpage2Component } from './landpage2.component';

describe('Landpage2Component', () => {
  let component: Landpage2Component;
  let fixture: ComponentFixture<Landpage2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Landpage2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(Landpage2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
