import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landpage',
  templateUrl: './landpage.component.html',
  styleUrls: ['./landpage.component.css']
})
export class LandpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
