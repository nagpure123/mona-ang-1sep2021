import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filterbutton',
  templateUrl: './filterbutton.component.html',
  styleUrls: ['./filterbutton.component.css']
})
export class FilterbuttonComponent implements OnInit {
 data = [
    { Name: 'John', Gender: 'male',  Email: 'john@hotmail.com' , Phone: '0987890987' },
    { Name: 'Mona', Gender: 'female',Email: 'mona@hotmail.com' , Phone: '1111111111'},
    { Name: 'Rama', Gender: 'male',  Email: 'rama@hotmail.com' , Phone: '2222222222' },
    { Name: 'Sumit', Gender: 'male', Email: 'sumit@hotmail.com', Phone: '3333333333' },
    { Name: 'Amol', Gender: 'male',  Email: 'amol@hotmail.com' , Phone: '888888888' },
    { Name: 'mit',  Gender: 'male',   Email: 'mit@hotmail.com' ,  Phone: '3333333888' },
    { Name: 'Pama', Gender: 'female',Email: 'pama@hotmail.com' , Phone: '3333333330' },
    { Name: 'Umesh', Gender: 'male', Email: 'umesh@hotmail.com', Phone: '3333337878' },
    { Name: 'Ramesh', Gender: 'male', Email: 'ramesh@hotmail.com', Phone: '3333333399' },
    { Name: 'Kamal', Gender: 'female', Email: 'kamal@hotmail.com', Phone: '3333333335' }

];
  constructor() { 
  
  }

  ngOnInit(): void {
  }



  // clearFilter = function() {
  //   search = {};
  // }
}
