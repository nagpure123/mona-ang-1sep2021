import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { MenuComponent } from './menu/menu.component';
import { MainbodyComponent } from './mainbody/mainbody.component';
import { FooterComponent } from './footer/footer.component';
import { LandpageComponent } from './landpage/landpage.component';
import { Landpage2Component } from './landpage2/landpage2.component';
import { NgswitchComponent } from './ngswitch/ngswitch.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatInputModule} from '@angular/material/input';
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { NgstyleclassComponent } from './ngstyleclass/ngstyleclass.component';
import { Comp1Component } from './comp1/comp1.component';
import { PracComponent } from './prac/prac.component';
// import { PropertyClassComponent } from './property-class/property-class.component';
import { PropertyclassComponent } from './propertyclass/propertyclass.component';
import {MatButtonModule} from '@angular/material/button';
import { FilterbuttonComponent } from './filterbutton/filterbutton.component';
import {MatRadioModule} from '@angular/material/radio';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MenuComponent,
    MainbodyComponent,
    FooterComponent,
    LandpageComponent,
    Landpage2Component,
    NgswitchComponent,
    NgstyleclassComponent,
    Comp1Component,
    PracComponent,
    PropertyclassComponent,
    FilterbuttonComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, BrowserAnimationsModule,MatInputModule,
    MatCardModule,MatFormFieldModule,MatDatepickerModule,MatButtonModule,MatRadioModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
