import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prac',
  templateUrl: './prac.component.html',
  styleUrls: ['./prac.component.css']
})
export class PracComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
