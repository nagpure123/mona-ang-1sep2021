import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngstyleclass',
  templateUrl: './ngstyleclass.component.html',
  styleUrls: ['./ngstyleclass.component.css']
})
export class NgstyleclassComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

Info:any = [
{
  name:"s1",
  country:"INDIA"
},
{
  name:"s2",
  country:"JAPAN"
},
{
  name:"s3",
  country:"US"
},
{
  name:"s4",
  country:"CHINA"
}

]

getColor(countryName:any){
switch(countryName){
  case  "INDIA":
  return 'red'

  case  "JAPAN":
    return 'black'
    case  "US":
      return 'blue'
      case  "CHINA":
        return 'green'
}


return

}


}
