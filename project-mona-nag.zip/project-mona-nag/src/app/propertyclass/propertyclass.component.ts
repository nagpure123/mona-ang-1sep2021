import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-propertyclass',
  templateUrl: './propertyclass.component.html',
  styleUrls: ['./propertyclass.component.css']
})
export class PropertyclassComponent implements OnInit {
  classofcss:string ='one two three four'
    image:string="https://images.pexels.com/photos/708587/pexels-photo-708587.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"

  Changecss(){
    this.classofcss ="newone"
  }
  Firstcss(){
    this.classofcss ="one two three four"
  }
  Friendsimg(){
    this.image="https://images.pexels.com/photos/3662824/pexels-photo-3662824.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
    

}
Familyimg()
{
this.image="https://images.pexels.com/photos/1682497/pexels-photo-1682497.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"
}





  constructor() { }

  ngOnInit(): void {
  }

}
